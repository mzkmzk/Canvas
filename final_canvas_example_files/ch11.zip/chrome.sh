/Applications/Google\ Chrome.app/Contents/MacOS/Google\ Chrome --disable-web-security
